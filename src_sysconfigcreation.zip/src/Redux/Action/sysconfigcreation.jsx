import { createAction } from "redux-actions";
import * as actions from "../constant";


export const postSysConfigcreationRequest = createAction(
      actions.POST_SYSCONFIGCREATION_REQUEST
);
export const postSysConfigcreationSuccess = createAction(
      actions.POST_SYSCONFIGCREATION_SUCCESS
);
export const postSysConfigcreationError = createAction(
      actions.POST_SYSCONFIGCREATION_ERROR
);
export const getglprimaryRequest = createAction(
      actions.GET_GLPRIMARY_REQUEST
);
export const getglprimarySuccess = createAction(
      actions.GET_GLPRIMARY_SUCCESS
);
export const getglprimaryError = createAction(
      actions.GET_GLPRIMARY_ERROR
);


