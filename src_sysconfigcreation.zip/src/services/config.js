export const CONFIG = {
  BASE_URL: "https://127.0.0.1:8000",
};
