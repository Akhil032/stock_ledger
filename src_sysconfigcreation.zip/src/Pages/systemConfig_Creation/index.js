import React, { useEffect, useState } from "react";
//import './Forms.css';
//import { useForm } from "react-hook-form";
import { Box } from '@mui/system';
import { Alert, TextField } from '@mui/material';
import { makeStyles } from "@mui/styles";
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import Autocomplete from '@mui/material/Autocomplete';
import { useDispatch, useSelector } from "react-redux";
import {postSysConfigcreationRequest,getglprimaryRequest} from "../../Redux/Action/sysconfigcreation";
import Grid from '@mui/material/Grid';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import swal from '@sweetalert/with-react';
import Select from 'react-select';
import makeAnimated from 'react-select/animated';

const animatedComponents = makeAnimated();
// const styleSelect = {
//   control: base => ({
//     ...base,
//     border: 0,
//     margin: "10px 0px 15px 335px",
//     width:"310px",
//     padding:"5px",
//     flexWrap:"wrap",
//     backgroundColor:"lightblue",
//     //border: "5px solid black",
//     // This line disable the blue border
//     boxShadow: 'none',
//     borderBottom: "1px solid black",
//     display: 'flex',
//   })
// };
const styleSelect1 = {
    control: base => ({
      ...base,
      border: 0,
      padding:"10px",
      margin: "10px 0px 15px 9px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect2 = {
control: base => ({
    ...base,
    border: 0,
    top:"-73px",
    padding:"10px",
    postion:"fixed",
    margin: "0px 0px 1px 335px",
    border: "1px solid lightgray",
    width:"312px",
})
};
const styleSelect3 = {
    control: base => ({
      ...base,
      border: 0,
      padding:"10px",
      top:"-141px",
      margin: "10px 0px 15px 663px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect4 = {
    control: base => ({
      ...base,
      border: 0,
      padding:"10px",
      top:"-135px",
      margin: "0px 0px 15px 9px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect5 = {
    control: base => ({
      ...base,
      border: 0,
      top:"-208px",
      padding:"10px",
      margin: "10px 0px 15px 335px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect6 = {
    control: base => ({
      ...base,
      border: 0,
      top:"-281px",
      padding:"10px",
      margin: "10px 0px 15px 663px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect7 = {
    control: base => ({
      ...base,
      border: 0,
      top:"-276px",
      padding:"10px",
      margin: "10px 0px 15px 9px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect8 = {
    control: base => ({
      ...base,
      border: 0,
      top:"-349px",
      padding:"10px",
      margin: "10px 0px 15px 335px",
      border: "1px solid lightgray",
      width:"310px",
    })
};
const styleSelect9 = {
    control: base => ({
      ...base,
      border: 0,
      top:"-422px",
      padding:"10px",
      margin: "10px 0px 15px 663px",
      border: "1px solid lightgray",
      width:"310px",
    })
};


const useStyles = makeStyles({
    maindiv: {
        position: "relative",
        // backgroundColor:"orange",
        height:"100vh",
        width: "calc(90vw - 10px)",
        '& table': {
            '& tr': {
                '& td:nth-child(28)': {
                    display: 'none'
                },
                '& td:nth-child(29)': {
                    display: 'none'
                },
                '& td:nth-child(30)': {
                    display: 'none'
                }
            }
        }
    }, boxDiv: {
        display:"flex",
        justifyContent:"space-between",
    },
    uploaddiv: {
        display: "flex",
        alignItems: "center",
        marginTop: "50px",
        textAlign: "start",
        gap: 20,
    },
    GobackDiv: {
        cursor: "pointer",
    },
    textField: {
        marginRight: "10px !important",
    },
    dateField: {
        '& .MuiInput-input': {
            color: "rgba(102,102,102,1)",
        }
    },
});




const initialData = {
    STCK_LDGR_APPL:"",
    SOH_IMPACT:"",
    COST_USED:"",
    PERIOD_INVT_TRAN:"",
    INJECT_PERIOD:"",
    OVERRIDE_ACCUMULATE:"",
    HIER_LEVEL:"",
    FIN_APPL:"",
    TRN_NAME:"",
    TRN_TYPE:"",
    AREF:"",
    ACCT_REFERENCE:"",
}

  const STCK_LDGR_APPL_VAL1=[
    {label:"Y"},
    {label:"N"},
  ];

const SOH_IMPACT_VAL=[
    {label:"A ",value:"ADD"},
    {label:"R ",value:"REDUCE"},
    {label:"N ",value:"NO IMPACT"}
  ];

  const COST_USED_VAL=[
    {label:"S",value:"STANDARD"},
    {label:"T",value:"TRANSACTION"}
  ];
  const PERIOD_INVT_TRAN_VAL=[
    {label:"Y"},
    {label:"N"},
  ];
  const INJECT_PERIOD_VAL=[
    {label:"D",value:"DAILY"},
    {label:"W",value:"WEEKLY"},
    {label:"M",value:"MONTHLY"},
    {label:"S",value:"FINANCE STAGE"}
  ];
  const OVERRIDE_ACCUMULATE_VAL=[
    {label:"O",value:"OVERRIDE"},
    {label:"A",value:"ACCUMULATE"}
  ];
  const HIER_LEVEL_VAL=[
    {label:"SKU"},
    {label:"HIER1"},
    {label:"HIER2"},{label:"HIER3"},
  ];
  const FIN_APPL_VAL=[
    {label:"Y"},
    {label:"N"},
  ];

//console.log("valus:", sendGLData)
const SystemConfigCreation = () => {
    // we're using react-hook-form library 
    //const { register, handleSubmit } = useForm();
    
    const [primary, setPrimary] = useState([{}]);
    const [load, setLoad] = useState(0);
    //const [itemData, setItemData] = useState(initialItemData);
    const [filterClass, setFilterClass] = useState([]);
    const [searchData, setSearchData] = useState(initialData);
    const [origItemData, setOrigItemData] = useState({});
    const [sendData, setSendData] = useState(initialData);
    const [isSubmit, setSubmit] = useState(false);
    const dispatch = useDispatch();
    const [isSearch, setSearch] = useState(false);
    const GLCreateClasses = useStyles();
    const theme = useTheme();
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [valCurr,setValCurr]=useState([]);
    const [isValid, setIsValid] = useState(false);
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const SystemConfigCreationData = useSelector(
        (state) => state.sysconfigcreationReducers
    );
    const [validateTRN_NAME, setValidateTRN_NAME] = useState(false)
    const [validateTRN_TYPE, setValidateTRN_TYPE] = useState(false)
    const [validateAREF, setValidateAREF] = useState(false)

    useEffect(() => {
        document.title = 'System Config Creation';
      },[]);

    //   const handleSubmit = (event) => {
    //     event.preventDefault();
    //       setSearch(true);
    //       setState({ ...state, 'right': open });
    //       //console.log("state",state);
    //   }
    const handleSubmit = () => {
        var check=0;
        // console.log("ta", searchData)
        console.log("ROW", searchData);
        searchData.TRN_NAME.length <= 0 ? setValidateTRN_NAME(true) :
        setValidateTRN_NAME(false);
        searchData.TRN_TYPE.length <= 0 ? setValidateTRN_TYPE(true) :
        setValidateTRN_TYPE(false);
        searchData.AREF.length <= 0 ? setValidateAREF(true) :
        setValidateAREF(false);
        const arr=[searchData]
        arr.filter((val) => {
            console.log("val",val)
            for (const [key, value] of Object.entries(val)) {
              if(value===""){
                setIsValid(true)
                check=1;
                break;
              }
              if(key=="AREF" ){
                if(isNaN(value) || String(Math.abs(value)).charAt(0) !== value){
                    check=1;
                    break;
                  }
              }
              if(key=="TRN_TYPE" && (value.length > 3 ||value.length < 3 ) ){
                console.log(343434)
                    check=1;
                    break;
              }
            }
        })
        if (check===1){
            swal(
            <div>     
                <p>{"All Fields Required* "}</p>
            </div>
            )
            setSendData(initialData)
        }
        if (check===0) {
            console.log("11222")
              dispatch(postSysConfigcreationRequest([searchData]));
            setSendData(initialData)  
            //     setOpen(true);
            //     setLoading(true); 
            //     initialsearch.PRIMARY_ACCOUNT = [];
                setTimeout(() => window.location.reload(), 1000)
            // }

            //setSubmit(true);
            //seteditRows([]);
        } else {
            setOpen(true);
            setLoading(false);
        }

        setOpen(false);
        setLoading(true);
    };
   
    useEffect(() => {
        if(isSearch){
          dispatch(postSysConfigcreationRequest([searchData])) 
          setSearch(false)
        }
      },[isSearch])

    //const Forms = () => {
    // we're using react-hook-form library 
    //const { register, handleSubmit } = useForm();
    useEffect(() => {
        if (SystemConfigCreationData.isError && SystemConfigCreationData.message) {
            swal(
              <div>     
                <p>{SystemConfigCreationData["message"]}</p>
              </div>
            )  
            SystemConfigCreationData.isError=false;
        }else if(SystemConfigCreationData.isSuccess && SystemConfigCreationData.message){
          swal(
            <div>     
               <p>{SystemConfigCreationData["message"]}</p>
            </div>
          )
          SystemConfigCreationData.isSuccess=false;
          setLoading(true);
        }
      }, [SystemConfigCreationData])
    

    const onChange = (sendData) => {
       // console.log("at", sendData.target.name,sendData.target.value)
        setSearchData((prev) => {
            return {
                ...prev,
                [sendData.target.name]: sendData.target.value,
            };
        });
    }
    const onSubmit = (data) => {
        //console.log("kty", data);
    };


    useEffect(() => {
        dispatch(getglprimaryRequest([{}]))
        
         }, [""])
         useEffect(() => {
            if (SystemConfigCreationData?.data?.primary && Array.isArray(SystemConfigCreationData?.data?.primary)) {
            
              setPrimary(SystemConfigCreationData?.data?.primary)
              setLoading(false);
              setSubmit(false);
              setSearch(false);
            }} ,[SystemConfigCreationData?.data]);
    console.log("primary",primary)
    const handleCancel = () => {
        setOpen(false)
    }
    const handleClose = () => {
        //setIsValidExcel(true);
        setOpen(false);
    };
const handleClickOpen = () => {
    var check=0;
    // if( inputCurr.length>0){
    //     for(var i = 0; i < itemData.length; i++) {
    //     check=1
    //     if ((itemData[i].CURRENCY).toUpperCase() === inputCurr.toUpperCase()) {
    //         selectCurrency(0,itemData[i])
    //         setInputCurr("");
    //         check=2;
    //         break;
    //     }
    //     } 
    // }
    if (check===1){
        swal(
        <div>     
            <p>{"No Data Found"}</p>
        </div>
        )
    }
    setOpen(true);
    };

    const select_STCK_LDGR_APPL  = (e,val) => {
        console.log("hello ",val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              STCK_LDGR_APPL : val.label,
            };
          });
        }
    }
    const select_SOH_IMPACT  = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              SOH_IMPACT : val.label,
            };
          });
        }
    }
    const select_COST_USED  = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              COST_USED : val.label,
            };
          });
        }
    }
    const select_PERIOD_INVT_TRAN  = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              PERIOD_INVT_TRAN : val.label,
            };
          });}
    }
    const select_INJECT_PERIOD  = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              INJECT_PERIOD : val.label,
            };
          });}
    }
    const select_OVER_ACC = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              OVERRIDE_ACCUMULATE : val.label,
            };
          });
        }
    }
    const select_HIER_LEVEL = (e,val) => {
        console.log(val)
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              HIER_LEVEL : val.label,
            };
          });
        }
    }
    const select_FIN_APPL = (e,val) => {
        console.log(val)
       
        if (val && val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              FIN_APPL : val.label,
            };
          });
        }
    }
    
    const selectACCT_REFERENCE = (e,val) => {
        console.log(val)
        if(val){
        if (val.length>0){
        setSearchData((prev) => {
            return {
              ...prev,
              ACCT_REFERENCE : val.PRIMARY_ACCOUNT,
            };
          });
        }
        else{
            setSearchData((prev) => {
                return {
                  ...prev,
                  ACCT_REFERENCE : "",
                };
              });
        }}
    }
    const Pop = props => {
  const { anchorEl, style, ...rest } = props
  const bound = anchorEl.getBoundingClientRect()
  return <div {...rest} style={{
    position: 'absolute',
    //zIndex: 9999,
    width: bound.width, margin:"-5px 1px 10px 660px"
  }} />
}
    console.log("sdsf",searchData)
    return (
        <Box className={GLCreateClasses.maindiv}>
            <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                    <Box className={GLCreateClasses.boxDiv}>
                        <div className={GLCreateClasses.uploaddiv}>
                            <h4>System Config Creation</h4>
                        </div>
                        <div className={GLCreateClasses.uploaddiv}>
                            {/* <div style={{ marginLeft: '16px', padding: '16px' }}> */}
                            <Button variant="contained" sx={{ marginTop: '15px', textAlign: 'right' }} onClick={handleClickOpen} startIcon={<SendIcon />}>
                                Submit
                            </Button>
                        </div>
                    </Box>
                </Grid>
                <div>
                    <Dialog
                        fullScreen={fullScreen}
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="responsive-dialog-title"
                        className={GLCreateClasses.popUp}
                        PaperProps={{
                            style: {
                                backgroundColor: '#D3D3D3',
                                borderRadius: '20px',
                            },
                        }}
                    >
                        <DialogTitle id="responsive-dialog-title">
                            {"Do you want to submit this Account!"}
                        </DialogTitle>
                        <DialogContent>                            
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus onClick={handleCancel}>
                                NO
                            </Button>
                            <Button onClick={handleSubmit} autoFocus>
                                YES
                            </Button>
                        </DialogActions>
                    </Dialog>
                </div>
            </Grid>
            <div className="container">
                {/* <h4 className="title">GL Account</h4> */}
                <div className="form-container">
                    <Box 
                    sx={{
                            '& .MuiTextField-root': { m: 1, width: '35ch'},
                            //display:"flex",
                            height:"100vh",
                            position:"fixed"
                        }}
                        autoComplete="off"
                        >
                        {/* <form sx={{backgroundColor:"red"}}> */}
                        <TextField 
                                variant="standard"
                                error={validateTRN_NAME}
                                helperText={validateTRN_NAME === true ? "*Required" : null}
                                name="TRN_NAME"
                                label="TRN NAME"
                                id="TRN NAME"
                                onChange={onChange}
                                required
                            />
                            <TextField
                                variant="standard"
                                error={validateTRN_TYPE}
                                helperText={validateTRN_TYPE === true ? "*Required" : null}
                                name="TRN_TYPE"
                                label="TRN TYPE"
                                id="TRN TYPE"
                                onChange={onChange}
                                required
                            />
                            <TextField
                                variant="standard"
                                error={validateAREF}
                                helperText={validateAREF === true ? "*Required" : null}
                                name="AREF"
                                label="AREF"
                                id="AREF"
                                onChange={onChange}
                                required
                            />
<Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            clearOnEscape
                            options={STCK_LDGR_APPL_VAL1}
                            //value={(searchData?.DEPT.length > 0)?searchData?.DEPT:[]}
                            sx={{ width: 250, margin:"0px 1px 10px 2px",position:"fixed"}}
                            onChange={select_STCK_LDGR_APPL} 
                            renderInput={(params) => 
                            <TextField {...params} label="STCK_LDGR_APPL" 
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
<Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={SOH_IMPACT_VAL}
                            renderOption={(props, option) => (
                                <Box component="li" {...props}>
                                  {option.label} ({option.value})
                                </Box>
                              )}
                              sx={{ width: 250, margin:"0px 3px 10px 330px" ,position:"absolute" }}
                            //sx={{ width: 250, margin:"-61px 1px 10px 335px" ,position:"fixed" }}
                            onChange={select_SOH_IMPACT} 
                            renderInput={(params) => 
                            <TextField {...params} label="SOH IMPACT"
                            variant="standard" 
                            
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                            <Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={COST_USED_VAL}
                            renderOption={(props, option) => (
                                <Box component="li" {...props}>
                                  {option.label} ({option.value})
                                </Box>
                              )}
                              sx={{ width: 250, margin:"0px 1px 0px 660px" ,position:"absolute" }}
                            onChange={select_COST_USED} 
                            renderInput={(params) => 
                            <TextField {...params} label="COST USED"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />

<Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={PERIOD_INVT_TRAN_VAL}
                            sx={{ width: 250, margin:"80px 1px 10px 2px",position:"fixed",border:"1px"}}
                            onChange={select_PERIOD_INVT_TRAN} 
                            renderInput={(params) => 
                            <TextField {...params} label="PERIOD INVT TRAN"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                            <Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={INJECT_PERIOD_VAL}
                            renderOption={(props, option) => (
                                <Box component="li" {...props}>
                                  {option.label} ({option.value})
                                </Box>
                              )}
                            sx={{ width: 250, margin:"80px 3px 10px 330px", position:"absolute" }}
                            onChange={select_INJECT_PERIOD} 
                            renderInput={(params) => 
                            <TextField {...params} label="INJECT PERIOD"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                            <Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={OVERRIDE_ACCUMULATE_VAL}
                            renderOption={(props, option) => (
                                <Box component="li" {...props}>
                                  {option.label} ({option.value})
                                </Box>
                              )}
                            sx={{ width: 250, margin:"80px 1px 10px 660px", position:"absolute"}}
                            onChange={select_OVER_ACC} 
                            renderInput={(params) => 
                            <TextField {...params} label="OVERRIDE ACCUMULATE"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                            <Autocomplete
                            
                            size="small"
                            id="clear-on-escape"
                            options={HIER_LEVEL_VAL}
                            sx={{ width: 250 , margin:"160px 1px 10px 2px",position:"fixed"}}
                            onChange={select_HIER_LEVEL} 
                            renderInput={(params) => 
                            <TextField {...params} label="HIER LEVEL"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                             <Autocomplete
                            size="small"
                            id="clear-on-escape"
                            options={FIN_APPL_VAL}
                            sx={{ width: 250, margin:"160px 3px 10px 330px" ,position:"absolute" }}
                            onChange={select_FIN_APPL} 
                            renderInput={(params) => 
                            <TextField {...params} label="FIN APPL"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                             <Autocomplete
                            size="small"
                            options={primary}
                              getOptionLabel={(option) =>  option.PRIMARY_ACCOUNT.toString()}
                            
                            sx={{ width: 310, margin:"160px 3px 10px 660px" ,position: 'absolute'}}
                            onChange={selectACCT_REFERENCE} 
                            renderInput={(params) => 
                            <TextField {...params} label="ACCT REFERENCE"
                            variant="standard" 
                            error={isValid}
                            helperText={isValid? "*Required" : null}
                            required
                            />}
                            />
                            {/* <Autocomplete
                                // multiple
                                size="small"
                                id="combo-box-location"
                                sx={{ width: 250 }}
                                options={(primary.length > 0)?primary:[]}
                                // value={searchData.LOCATION}
                                renderOption={(props, option) => (
                                    <Box component="li" {...props}>
                                      {option.PRIMARY_ACCOUNT}
                                    </Box>
                                  )}
                                  getOptionLabel={(option) =>  option.PRIMARY_ACCOUNT.toString()}
                                autoHighlight                                
                                onChange={selectACCT_REFERENCE}
                                renderInput={(params) => (
                                    <TextField
                                    {...params}
                                    variant="standard" 
                                    label="Choose a Location"
                                    inputProps={{
                                        ...params.inputProps,
                                        autoComplete: 'new-password', // disable autocomplete and autofill
                                    }}
                                    />
                                )}
                                /> */}

                            
                           
                            <Grid item xs={6}>
                                <Box display="flex"
                                    justifyContent="flex-end"
                                    alignItems="flex-end" className={GLCreateClasses.boxDiv}>
                                </Box>
                            </Grid>


                            {/* <Button variant="contained" sx={{marginTop: '15px'}} type="Submit"    startIcon={<SendIcon />}>Submit</Button> */}
                            {/* </div> */}
                        {/* </form> */}
                    </Box>
                </div>
            </div>
        </Box>
    );
};

export default SystemConfigCreation;