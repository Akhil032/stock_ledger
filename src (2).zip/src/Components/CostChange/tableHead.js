export const headCells = [
  {
    id: "ITEM",
    numeric: true,
    disablePadding: false,
    label: "ITEM",
    width: "100%",
  },
  
  {
    id: "ITEM_DESC",
    numeric: true,
    disablePadding: false,
    label: "ITEM DESC",
    width: "100%",
    //width: "150px",
  },
 
  {
    id: "LOCATION",
    numeric: true,
    disablePadding: false,
    label: "LOCATION",
    width: "100%",
  },
  {
    id: "LOCATION_NAME",
    numeric: true,
    disablePadding: false,
    label: "LOCATION NAME",
    width: "100%",
  },
  {
    id: "ITEM_SOH",
    numeric: false,
    disablePadding: true,
    label: "ITEM SOH",
    width: "100%",
  },
  {
    id: "UNIT_COST",
    numeric: true,
    disablePadding: false,
    label: "UNIT COST",
    width: "100%",
    
  },
 ];
