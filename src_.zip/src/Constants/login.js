export const UsersList=[{
    username:'admin',
    password:'admin'
},
{
    username:'Tarun',
    password:'Tarun'
},
{
    username:'Akhil',
    password:'Cicada'
},
{
    username:'Alex',
    password:'Proxima@360'
}]