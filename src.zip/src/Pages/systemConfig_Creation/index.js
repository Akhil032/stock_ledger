import React, { useEffect, useState } from "react";
//import './Forms.css';
//import { useForm } from "react-hook-form";
import { Box } from '@mui/system';
import { Alert, TextField } from '@mui/material';
import { makeStyles } from "@mui/styles";
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import Autocomplete from '@mui/material/Autocomplete';
import { useDispatch, useSelector } from "react-redux";
import {postSysConfigcreationRequest} from "../../Redux/Action/sysconfigcreation";
import Grid from '@mui/material/Grid';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import swal from '@sweetalert/with-react';
import Select from 'react-select';
import makeAnimated from 'react-select/animated';

const animatedComponents = makeAnimated();
const styleSelect = {
  control: base => ({
    ...base,
    border: 0,
    margin: "10px 0px 0px 10px",
    width:"310px",
    //border: "5px solid black",
    // This line disable the blue border
    boxShadow: 'none',
    borderBottom: "1px solid black"
  })
};


const useStyles = makeStyles({
    maindiv: {
        position: "relative",
        width: "calc(90vw - 10px)",
        '& table': {
            '& tr': {
                '& td:nth-child(28)': {
                    display: 'none'
                },
                '& td:nth-child(29)': {
                    display: 'none'
                },
                '& td:nth-child(30)': {
                    display: 'none'
                }
            }
        }
    }, boxDiv: {
        display:"flex",
        justifyContent:"space-between",
    },
    uploaddiv: {
        display: "flex",
        alignItems: "center",
        marginTop: "50px",
        textAlign: "start",
        gap: 20,
    },
    GobackDiv: {
        cursor: "pointer",
    },
    textField: {
        marginRight: "10px !important",
    },
    dateField: {
        '& .MuiInput-input': {
            color: "rgba(102,102,102,1)",
        }
    },
  
});




const initialData = {
    STCK_LDGR_APPL:"",
    SOH_IMPACT:"",
    COST_USED:"",
    PERIOD_INVT_TRAN:"",
    INJECT_PERIOD:"",
    OVERRIDE_ACCUMULATE:"",
    HIER_LEVEL:"",
    FIN_APPL:"",
    TRN_NAME:"",
    TRN_TYPE:"",
    AREF:"",
}
const STCK_LDGR_APPL_VAL=[
    {value:"Y"},
    {value:"N"},
  ];
const SOH_IMPACT_VAL=[
    {label:"A (ADD)",value:"A"},
    {label:"R (REDUCE)",value:"R"},
    {label:"N (NO IMPACT)",value:"N"}
  ];

  const COST_USED_VAL=[
    {label:"S (STANDARD)",value:"S"},
    {label:"T (TRANSACTION)",value:"T"}
  ];
  const PERIOD_INVT_TRAN_VAL=[
    {value:"Y"},
    {value:"N"},
  ];
  const INJECT_PERIOD_VAL=[
    {label:"D (DAILY)",value:"D"},
    {label:"W (WEEKLY)",value:"W"},
    {label:"M (MONTHLY)",value:"M"},
    {label:"S (FINANCE STAGE)",value:"S"}
  ];
  const OVERRIDE_ACCUMULATE_VAL=[
    {label:"O (OVERRIDE)",value:"O"},
    {label:"A (ACCUMULATE)",value:"A"}
  ];
  const HIER_LEVEL_VAL=[
    {value:"SKU"},
    {value:"HIER1"},
    {value:"HIER2"},{value:"HIER3"},
  ];
  const FIN_APPL_VAL=[
    {value:"Y"},
    {value:"N"},
  ];

//console.log("valus:", sendGLData)
const SystemConfigCreation = () => {
    // we're using react-hook-form library 
    //const { register, handleSubmit } = useForm();
    
    const [inputCurr, setInputCurr] = useState("");
    const [load, setLoad] = useState(0);
    //const [itemData, setItemData] = useState(initialItemData);
    const [filterClass, setFilterClass] = useState([]);
    const [searchData, setSearchData] = useState(initialData);
    const [origItemData, setOrigItemData] = useState({});
    const [sendData, setSendData] = useState(initialData);
    const [isSubmit, setSubmit] = useState(false);
    const dispatch = useDispatch();
    const [isSearch, setSearch] = useState(false);
    const GLCreateClasses = useStyles();
    const theme = useTheme();
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [valCurr,setValCurr]=useState([]);
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const GlAccountData = useSelector(
        (state) => state.sysconfigcreationReducers
    );
    const [validateTRN_NAME, setValidateTRN_NAME] = useState(false)
    const [validateTRN_TYPE, setValidateTRN_TYPE] = useState(false)
    const [validateAREF, setValidateAREF] = useState(false)

    useEffect(() => {
        document.title = 'Account Creation';
      },[]);

    //   const handleSubmit = (event) => {
    //     event.preventDefault();
    //       setSearch(true);
    //       setState({ ...state, 'right': open });
    //       //console.log("state",state);
    //   }
    const handleSubmit = () => {
        var check=0;
        // console.log("ta", searchData)
        console.log("ROW", searchData);
        searchData.TRN_NAME.length <= 0 ? setValidateTRN_NAME(true) :
        setValidateTRN_NAME(false);
        searchData.TRN_TYPE.length <= 0 ? setValidateTRN_TYPE(true) :
        setValidateTRN_TYPE(false);
        searchData.AREF.length <= 0 ? setValidateAREF(true) :
        setValidateAREF(false);
        const arr=[searchData]
        arr.filter((val) => {
            console.log("val",val)
            for (const [key, value] of Object.entries(val)) {
              if(value===""){
                check=1;
                break;
              }
            }
        })
        if (check===1){
            swal(
            <div>     
                <p>{"Fill Required* fields"}</p>
            </div>
            )
            setSendData(initialData)
        }
        if (check===0) {
            console.log("11222")
              dispatch(postSysConfigcreationRequest([searchData]));
            setSendData(initialData)  
            //     setOpen(true);
            //     setLoading(true); 
            //     initialsearch.PRIMARY_ACCOUNT = [];
            //     setTimeout(() => window.location.reload(), 500)
            // }

            //setSubmit(true);
            //seteditRows([]);
        } else {
            setOpen(true);
            setLoading(false);
        }

        setOpen(false);
        setLoading(true);
    };
   
    useEffect(() => {
        if(isSearch){
          dispatch(postSysConfigcreationRequest([searchData])) 
          setSearch(false)
        }
      },[isSearch])

    //const Forms = () => {
    // we're using react-hook-form library 
    //const { register, handleSubmit } = useForm();
    useEffect(() => {
        if (GlAccountData.isError && GlAccountData.message) {
            swal(
              <div>     
                <p>{GlAccountData["message"]}</p>
              </div>
            )  
            GlAccountData.isError=false;
        }else if(GlAccountData.isSuccess && GlAccountData.message){
          swal(
            <div>     
               <p>{GlAccountData["message"]}</p>
            </div>
          )
          GlAccountData.isSuccess=false;
          setLoading(true);
        }
      }, [GlAccountData])
    

    const onChange = (sendData) => {
       // console.log("at", sendData.target.name,sendData.target.value)
        setSearchData((prev) => {
            return {
                ...prev,
                [sendData.target.name]: sendData.target.value,
            };
        });
    }
    const onSubmit = (data) => {
        //console.log("kty", data);
    };


    useEffect(() => {
        // if(GlAccountData?.data?.Data && Array.isArray(GlAccountData?.data?.Data)){
        //   setTabledata(serializedata(GlAccountData?.data?.Data));
        //   setAllData(serializedata(GlAccountData?.data?.Data));
        //   setLoading(false);
        //   setSubmit(false);
        //   setSearch(false);
        //}
        // if (GlAccountData?.data?.CURRENCYDATA && Array.isArray(GlAccountData?.data?.CURRENCYDATA)) {
        //         setItemData(GlAccountData?.data?.CURRENCYDATA);
        //         setOrigItemData(GlAccountData?.data?.CURRENCYDATA);


        //     //setLoading(false);
        //     // }else if(GlAccountData?.data?.locationData && Array.isArray(GlAccountData?.data?.locationData)){
        //     //   setLocationData(GlAccountData?.data?.locationData);
        //     //setLoading(false);
        // } else {
        //     //setSearch(false)
        // }

    }, [GlAccountData?.data])
//console.log("GlAccountData",GlAccountData)
    // const handleSubmit = (evt) => {
    //     evt.preventDefault();
    //     //var a={itemData,sendData}
    //     //a.push({})
    //     ////console.log("sdsd",a)
    //     //console.log("abc",sendData);   
    //    // //console.log(itemData)
    //      Alert("stop") 
    //   };

    
    const handleCancel = () => {
        setOpen(false)
    }
    const handleClose = () => {
        //setIsValidExcel(true);
        setOpen(false);
    };
const handleClickOpen = () => {
    var check=0;
    // if( inputCurr.length>0){
    //     for(var i = 0; i < itemData.length; i++) {
    //     check=1
    //     if ((itemData[i].CURRENCY).toUpperCase() === inputCurr.toUpperCase()) {
    //         selectCurrency(0,itemData[i])
    //         setInputCurr("");
    //         check=2;
    //         break;
    //     }
    //     } 
    // }
    if (check===1){
        swal(
        <div>     
            <p>{"No Data Found"}</p>
        </div>
        )
    }
    setOpen(true);
    };

    const select_STCK_LDGR_APPL  = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              STCK_LDGR_APPL : val.value,
            };
          });
    }
    const select_SOH_IMPACT  = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              SOH_IMPACT : val.value,
            };
          });
    }
    const select_COST_USED  = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              COST_USED : val.value,
            };
          });
    }
    const select_PERIOD_INVT_TRAN  = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              PERIOD_INVT_TRAN : val.value,
            };
          });
    }
    const select_INJECT_PERIOD  = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              INJECT_PERIOD : val.value,
            };
          });
    }
    const select_OVER_ACC = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              OVERRIDE_ACCUMULATE : val.value,
            };
          });
    }
    const select_HIER_LEVEL = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              HIER_LEVEL : val.value,
            };
          });
    }
    const select_FIN_APPL = (val) => {
        console.log(val)
        setSearchData((prev) => {
            return {
              ...prev,
              FIN_APPL : val.value,
            };
          });
    }
    console.log("sdsf",searchData)
    return (
        <Box className={GLCreateClasses.maindiv}>
            <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                    <Box className={GLCreateClasses.boxDiv}>
                        <div className={GLCreateClasses.uploaddiv}>
                            <h4>System Config Creation</h4>
                        </div>
                        <div className={GLCreateClasses.uploaddiv}>
                            {/* <div style={{ marginLeft: '16px', padding: '16px' }}> */}
                            <Button variant="contained" sx={{ marginTop: '15px', textAlign: 'right' }} onClick={handleClickOpen} startIcon={<SendIcon />}>
                                Submit
                            </Button>
                        </div>
                    </Box>
                </Grid>
                <div>
                    <Dialog
                        fullScreen={fullScreen}
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="responsive-dialog-title"
                        className={GLCreateClasses.popUp}
                        PaperProps={{
                            style: {
                                backgroundColor: '#D3D3D3',
                                borderRadius: '20px',
                            },
                        }}
                    >
                        <DialogTitle id="responsive-dialog-title">
                            {"Do you want to submit this Account!"}
                        </DialogTitle>
                        <DialogContent>                            
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus onClick={handleCancel}>
                                NO
                            </Button>
                            <Button onClick={handleSubmit} autoFocus>
                                YES
                            </Button>
                        </DialogActions>
                    </Dialog>
                </div>
            </Grid>
            <div className="container">
                {/* <h4 className="title">GL Account</h4> */}
                <div className="form-container">

                    <Box

                        sx={{
                            '& .MuiTextField-root': { m: 1, width: '35ch' },
                        }}
                        autoComplete="off"

                    >
                        <form>
                        <TextField
                                error={validateTRN_NAME}
                                 helperText={validateTRN_NAME === true ? "*Required" : null}
                                name="TRN_NAME"
                                label="TRN NAME"
                                id="TRN NAME"
                                onChange={onChange}
                                required
                            />
                            <TextField
                                error={validateTRN_TYPE}
                                helperText={validateTRN_TYPE === true ? "*Required" : null}
                                name="TRN_TYPE"
                                label="TRN TYPE"
                                id="TRN TYPE"
                                onChange={onChange}
                                required
                            />
                            <TextField
                                error={validateAREF}
                                helperText={validateAREF === true ? "*Required" : null}
                                name="AREF"
                                label="AREF"
                                id="AREF"
                                onChange={onChange}
                                required
                            />
                             <div style={{width: '320px'}}>
                            <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.value}
                            getOptionValue={option => option.value}
                            options={STCK_LDGR_APPL_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_STCK_LDGR_APPL}
                            placeholder={"STCK_LDGR_APPL"}
                            styles={styleSelect}
                            required
                             />
                             <br></br>
                            <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.label}
                            getOptionValue={option => option.value}
                            options={SOH_IMPACT_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_SOH_IMPACT}
                            placeholder={"SOH IMPACT"}
                            styles={styleSelect}
                            
                            />
                            <br></br>
                            <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.label}
                            getOptionValue={option => option.value}
                            options={COST_USED_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_COST_USED}
                            placeholder={"COST USED"}
                            styles={styleSelect}
                            />
                            <br></br>
                            <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.value}
                            getOptionValue={option => option.value}
                            options={PERIOD_INVT_TRAN_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_PERIOD_INVT_TRAN}
                            placeholder={"PERIOD INVT TRAN"}
                            styles={styleSelect}
                            />
                            <br></br>
                        <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.label}
                            getOptionValue={option => option.value}
                            options={INJECT_PERIOD_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_INJECT_PERIOD}
                            placeholder={"INJECT PERIOD"}
                            styles={styleSelect}
                            />
                            <br></br>


                        <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.label}
                            getOptionValue={option => option.value}
                            options={OVERRIDE_ACCUMULATE_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_OVER_ACC}
                            placeholder={"OVERRIDE ACCUMULATE"}
                            styles={styleSelect}
                            /><br></br>


                        <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.value}
                            getOptionValue={option => option.value}
                            options={HIER_LEVEL_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_HIER_LEVEL}
                            placeholder={"HIER LEVEL"}
                            styles={styleSelect}
                            /><br></br>

                        <Select 
                            closeMenuOnSelect={true}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            getOptionLabel={option => option.value}
                            getOptionValue={option => option.value}
                            options={FIN_APPL_VAL}
                            isSearchable={true}
                            // onInputChange={(value, action) => {
                            //   if (action.action === "input-change") setInputErr(value);
                            // }}
                            // inputValue={inputErr}
                            onChange={select_FIN_APPL}
                            placeholder={"FIN APPL"}
                            styles={styleSelect}
                            />
                            </div>
                            
           

                            <Grid item xs={6}>
                                <Box display="flex"
                                    justifyContent="flex-end"
                                    alignItems="flex-end" className={GLCreateClasses.boxDiv}>

                                </Box>
                            </Grid>


                            {/* <Button variant="contained" sx={{marginTop: '15px'}} type="Submit"    startIcon={<SendIcon />}>Submit</Button> */}
                            {/* </div> */}
                        </form>
                    </Box>

                </div>
            </div>
        </Box>
    );
};

export default SystemConfigCreation;