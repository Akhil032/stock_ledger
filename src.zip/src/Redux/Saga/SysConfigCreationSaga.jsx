import { call, put, takeLatest } from "redux-saga/effects";
import {
  postSysConfigcreationSuccess,
  postSysConfigcreationError,  
} from "../Action/sysconfigcreation";
import * as actions from "../constant";
import axiosCall from "../../services/index";
import { API } from "../../services/api";

// function* fetchDataSaga(action) {
//   try {
//     const response = yield call(axiosCall, "POST", API.FETCHGLACCOUNT,action.payload);
//     if (response?.data?.status == 500) {
//       yield put(getGlAccountError({Data: response?.data}));
//     } else {
//       yield put(getGlAccountListSuccess({ Data: response?.data }));
//     }
//   } catch (e) {
//     yield put(getGlAccountError(e.message));
//   }
// }

// export function* GlAccount() {
//   yield takeLatest(actions.GET_GLACCOUNT_REQUEST, fetchDataSaga);
// }


function* insertDataSaga(action) {
  try {
    const response = yield call(axiosCall, "POST", API.CREATESYSCONF,action.payload);
    if (response?.status == 200) {
      yield put(postSysConfigcreationSuccess({ Data: response?.data }));
    } else {
      yield put(postSysConfigcreationError(response?.data?.message));
    }
  } catch (e) {
    yield put(postSysConfigcreationError(e.message));
  }
}

export function* SysConfigcreation() {
  yield takeLatest(actions.POST_GLCREATION_REQUEST, insertDataSaga);
}

