import { createAction } from "redux-actions";
import * as actions from "../constant";


export const postSysConfigcreationRequest = createAction(
      actions.POST_SYSCONFIGCREATION_REQUEST
);
export const postSysConfigcreationSuccess = createAction(
      actions.POST_SYSCONFIGCREATION_SUCCESS
);
export const postSysConfigcreationError = createAction(
      actions.POST_SYSCONFIGCREATION_ERROR
);


